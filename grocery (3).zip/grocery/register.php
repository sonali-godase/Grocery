

<?php include("header.php");?>

<main>
   <!-- section -->

   <section class="my-lg-14 my-8">
      <!-- container -->
      <div class="container">
         <!-- row -->
         <div class="row justify-content-center align-items-center">
            <div class="col-12 col-md-6 col-lg-4 order-lg-1 order-2">
               <!-- img -->
               <img src="assets/images/svg-graphics/signup-g.svg" alt="" class="img-fluid">
            </div>
            <!-- col -->
            <div class="col-12 col-md-6 offset-lg-1 col-lg-4 order-lg-2 order-1">
               <div class="mb-lg-9 mb-5">
                <?php

                if (isset($_SESSION['success'])) 
                {

                  ?>

                  <div class="alert alert-danger text-center">
                     <b>
                        <?php echo $_SESSION['success']; ?>
                     </b>
                  </div>

                  <?php 

                  session_destroy();

               }


               ?>

               <h1 class="mb-1 h2 fw-bold">Get Start Shopping</h1>
               <p>Welcome to E-Grocery Shop! Enter your email to get started.</p>
            </div>
            <!-- form -->
            <form class="needs-validation" novalidate="" action="register_code.php" method="post"> 
               <div class="row g-3">
                  <!-- col -->
                  <div class="col-12">
                     <!-- input -->
                     <label for="formSignupfname" class="form-label visually-hidden">Name</label>
                     <input type="text" class="form-control" id="formSignupfname" placeholder="Name" name="name" required="">
                     <div class="invalid-feedback">Please enter name.</div>
                  </div>
                  <div class="col-12">
                     <!-- input -->
                     <label for="formSignupEmail" class="form-label visually-hidden">Email address</label>
                     <input type="email" class="form-control"  id="formSignupEmail" placeholder="Email" name="email" required="">
                     <div class="invalid-feedback">Please enter email.</div>
                  </div>

                  <div class="col-12">
                     <!-- input -->
                     <label for="formSignuplname" class="form-label visually-hidden">Mobile</label>
                     <input type="number" class="form-control" id="formSignuplname" placeholder="Mobile" name="mobile" required="">
                     <div class="invalid-feedback">Please enter Mobile.</div>
                  </div>

                  <div class="col-12">
                     <!-- input -->
                     <label for="formSignuplname" class="form-label visually-hidden">Address</label>
                     <input type="text" class="form-control" id="formSignuplname" placeholder="Address" name="address" required="">
                     <div class="invalid-feedback">Please Address.</div>
                  </div>

                  <div class="col-12">
                     <div class="password-field position-relative">
                        <label for="formSignupPassword" class="form-label visually-hidden">Password</label>
                        <div class="password-field position-relative">
                           <input type="password" class="form-control fakePassword" id="formSignupPassword" placeholder="*****" name="password" required="">

                           <div class="invalid-feedback">Please enter password.</div>
                        </div>
                     </div>
                  </div>
                  <!-- btn -->
                  <div class="col-12 d-grid"><button type="submit" class="btn btn-primary">Register</button></div>

                  <!-- text -->
                  <p>
                     <small>
                        Already have account ?
                        <a href="login.php">Login Now</a>
                     </small>
                  </p>
               </div>
            </form>
         </div>
      </div>
   </div>
</section>
</main>


<?php include("footer.php");?>