<?php include("header.php");


?>
<main>

	<div class="mt-8 mb-lg-14 mb-8">
		<!-- container -->
		<div class="container">
			<!-- row -->
			<div class="row gx-10">
				<!-- col -->

				<section class="col-lg-12 col-md-12">
					<!-- card -->
					<form action="all_product.php" method="GET">
					<div class="card mb-4 bg-light border-0">
						<!-- card body -->
						<div class="card-body p-9">
							<div class="row">
								<div class="col-md-3">
									<h2 class="mb-0 fs-1"> Products</h2>
								</div>

								<div class="col-md-3">
									<select name="cat_id" class="form-control" required>
											<option>Select Category</option>
										<?php 

										include('connection.php');

										$query = "SELECT * FROM category";

										$result = mysqli_query($conn, $query);

										while($row = mysqli_fetch_array($result)) 
										{

											?>

											<option value="<?= $row['cat_id'];?>">  <?= $row['cat_name'];?> </option>

											<?php
										}

										?>

									</select>
								</div>

								<div class="col-md-3">
									<select class="form-control" name="price" required>
										<option>Select Price</option>
										<option value="10"> < 10 </option>
										<option value="20"> < 20 </option>
										<option value="50"> < 50 </option>
										<option value="100"> < 100 </option>
										<option value="500"> < 500 </option>
										<option value="1000"> < 1000 </option>
									</select>
								</div>	
								<div class="col-md-2">
										<button type="submit" class="btn btn-primary form-control">Find </button>
								</div>							
							</div>
						</div>
					</div>
				</form>


					<!-- list icon -->

					<!-- row -->
					<div class="row g-4 row-cols-xl-4 row-cols-lg-3 row-cols-2 row-cols-md-2 mt-2">
						<!-- col -->
						<?php 

						$query = "SELECT * FROM products ";
						if (isset($_GET['search'])) 
						{
							$search = $_GET['search'];	
							$query .= "WHERE title like '%$search%'";
						}

						if (isset($_GET['cat_id'])) 
						{
							$cat_id = $_GET['cat_id'];	
							$price = $_GET['price'];
							$query .= "WHERE cat_id = '$cat_id' AND price<$price";


						}

						$result = mysqli_query($conn, $query);

						$count = mysqli_num_rows($result);

						
						if ($count==0) {

							echo "<h4 class='text-center text-danger'> No Product Found </h4>";
						}

						while($row = mysqli_fetch_array($result)) 
						{

							?>

							<div class="col">
								<!-- card -->
								<div class="card card-product">
									<div class="card-body">
										<!-- badge -->
										<div class="text-center position-relative">
											<a href="product_detail.php?product_id=<?= $row['product_id'];?>"><img src="admin/<?= $row['image'];?>" alt="Grocery Ecommerce Template" class="mb-3 img-fluid"></a>
											<!-- action btn -->

										</div>
										<!-- heading -->
										
										<h2 class="fs-6"><a href="shop-single.html" class="text-inherit text-decoration-none"><?= $row['title'];?></a></h2>

										<!-- price -->
										<div class="d-flex justify-content-between align-items-center mt-3">
											<div>
												<span class="text-dark">₹ <?= $row['price'];?></span>
											</div>
											<!-- btn -->
											<div>
												<a href="product_detail.php?product_id=<?php echo $row['product_id'];?>" class="btn btn-primary btn-sm">
													<i class="bi bi-eye"> </i>
													view
												</a>
											</div>
										</div>
									</div>
								</div>
							</div>
							<?php 
						}
						?>
					</div>

				</section>
			</div>
		</div>
	</div>
</main>

<?php include("footer.php");?>