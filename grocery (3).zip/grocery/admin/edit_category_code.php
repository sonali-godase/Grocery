<?php

session_start();
include('connection.php');
$cat_id=$_POST['cat_id'];
$cat_name=$_POST['cat_name'];

$query="UPDATE category set cat_name='$cat_name' where cat_id='$cat_id'";

mysqli_query($conn,$query);
$_SESSION['success'] = "Record Updated Successfully";
header("location:category_list.php");
?>