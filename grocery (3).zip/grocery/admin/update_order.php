<?php

session_start();
include('connection.php');
$order_id=$_GET['order_id'];


if (isset($_GET['status'])) 
{


	$query="UPDATE orders set status='In process' where order_id='$order_id'";

	mysqli_query($conn,$query);
}
else
{
	$query="UPDATE orders set status='Completed' where order_id='$order_id'";


	mysqli_query($conn,$query);
}

$_SESSION['success'] = "Order Updated Successfully";
header("location:order_list.php");
?>