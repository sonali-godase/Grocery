<?php  include('header.php');?>

                <!-- Begin Page Content -->
                <div class="container-fluid">

                    <!-- Page Heading -->
                    <h1 class="h3 mb-2 text-gray-800">Products List</h1>
                  
                    <!-- DataTales Example -->
                    <div class="card shadow mb-4">

                         <?php
                                        
                               if(isset($_SESSION['success']))
                                 { ?>
                                   <div class="alert alert-danger m-2">
                                     <strong> <?= $_SESSION['success'];?> </strong>
                                   </div>
                                          
                              <?php unset($_SESSION['success']); }
                                                              
                          ?>
                        <div class="card-header py-3">
                          <div class="row">

                            <div class="col-lg-6"> 
                                  <h6 class="m-0 font-weight-bold text-primary">Products</h6>         


                            </div>

                            <div class="col-lg-6 text-right">
                               <a href="add_product.php" class="btn btn-primary btn-sm"> Add products</a>
                            </div>
                              
                          </div>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                    <thead>
                                        <tr>

                                            <th>Products ID</th>
                                            <th> Image</th>
                                            <th>Name</th>
                                            <th>Price</th>
                                            <th>Category </th>
                                            <th>Description</th>
                                             <th>Delete</th>
                                             <th>Edit </th>
                              
                                           
                                        </tr>
                                    </thead>
                                  
                                   <tbody>

                                    <?php 

                                        include('connection.php');

                                        $query = "SELECT *,(SELECT cat_name FROM category WHERE category.cat_id = products.cat_id) AS cat_name FROM products";

                                        $result = mysqli_query($conn, $query);

                                        while($row = mysqli_fetch_assoc($result)) 
                                        {
                                              
                                           

                                            ?>
                                            <tr>
                                                <td> <?php echo $row['product_id'];?> </td>
                                                  <td> <a href="" target="_blank"> <img src="<?php echo $row['image']; ?>" width="80px"> </a> </td>
                                                <td> <?php echo $row['title'];?> </td>
                                                <td> ₹ <?php echo $row['price'];?> </td>
                                                <td> <?php echo $row['cat_name'];?>  </td>
                                                <td> <?php echo $row['description'];?> </td>
                                                <td><a href="delete_product.php?id=<?php echo $row['product_id'];?>" onclick="return confirm('Are you sure ?')">Delete</a></td>
                                                <td><a href="edit_product.php?id=<?php echo $row['product_id'];?>">Edit</a></td>
                                            </tr>

                                        <?php
                                            }

                                        ?>

                                   </tbody>
                                </table>
                            </div>
                        </div>
                    </div>

                </div>
                <!-- /.container-fluid -->

           

<?php  include('footer.php');?>
