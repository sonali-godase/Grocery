<?php

	session_start();
 	include('connection.php');


	$title = $_POST['title'];
	$price = $_POST['price'];
	$cat_id = $_POST['cat_id'];
	$description = $_POST['description'];

	 $filename=$_FILES['image']['name'];       // Get file name
    $tmp_name = $_FILES['image']['tmp_name'];   // for temporary Location
    $folder = "upload/".$filename;        // set folder path
    move_uploaded_file($tmp_name, $folder);     // Upload file into folder


	
	$query = "INSERT INTO products(title,price,cat_id,description, image) VALUES('$title','$price','$cat_id','$description', '$folder')";


	mysqli_query($conn, $query);

	$_SESSION['success'] = "Record Added Successfully";
	header("location:product_list.php");

?>