<?PHP
include('connection.php');
$cat_id=$_GET['id'];
$query="SELECT * FROM category WHERE cat_id='$cat_id'";
$result =mysqli_query($conn,$query);
$data=mysqli_fetch_assoc($result);
$cat_name=$data["cat_name"];
?>


<?php  include('header.php');?>


  <div class="container-fluid">

  <h1 class="h3 mb-2 text-gray-800">Edit Category</h1>
                  
                    <!-- DataTales Example -->
                    <div class="card shadow mb-4">
                       
                        <div class="card-body">

                        	<form action="edit_category_code.php" method="post">

                        		<input type="hidden" name="cat_id" class="form-control " value="<?php echo $cat_id;?>" required>
                        		
                        		<div >

                        			<label> Category Name</label>
                        			<input type="text" name="cat_name" class="form-control " value="<?php echo $cat_name;?>" required>
                        		</div>

                        		<div class="mt-4">
                        			<input type="submit" name="" class="btn btn-primary" value="Save">
                        		</div>


                        	</form>


                        </div>
                    </div>


  </div>

<?php  include('footer.php');?>