<?php 

	$conn = mysqli_connect('localhost', 'root', '', 'grocery1');

?>