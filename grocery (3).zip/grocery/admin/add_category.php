<?php  include('header.php');?>


  <div class="container-fluid">

  <h1 class="h3 mb-2 text-gray-800">Add Category</h1>
                  
                    <!-- DataTales Example -->
                    <div class="card shadow mb-4">
                       
                        <div class="card-body">

                        	<form action="add_categroy_code.php" method="post">
                        		
                        		<div >
                        			<label> Category Name</label>
                        			<input type="text" name="cat_name" class="form-control" required>
                        		</div>

                        		<div class="mt-4">
                        			<input type="submit" name="" class="btn btn-primary" value="Save">
                        		</div>


                        	</form>


                        </div>
                    </div>


  </div>

<?php  include('footer.php');?>