<?PHP
include('connection.php');
$product_id=$_GET['id'];
$query="SELECT * FROM products WHERE product_id='$product_id'";
$result =mysqli_query($conn,$query);
$data=mysqli_fetch_assoc($result);
$title=$data["title"];
$price=$data["price"];
$cat_id=$data["cat_id"];
$description=$data["description"];
      $image = $data['image'];
?>


<?php  include('header.php');?>


  <div class="container-fluid">

  <h1 class="h3 mb-2 text-gray-800">Edit product</h1>
                  
                    <!-- DataTales Example -->
                    <div class="card shadow mb-4">
                       
                        <div class="card-body">

                        	<form action="edit_product_code.php" method="post"   enctype="multipart/form-data">

                        		<input type="hidden" name="product_id" class="form-control " value="<?php echo $product_id;?>" required>
                        		
                        		<div class="form-group">

                        			<label> Product Name</label>
                        			<input type="text" name="title" class="form-control " value="<?php echo $title;?>" required> 
                            </div>
                            <div class="form-group">
                              <label> Price</label>
                              <input type="text" name="price" class="form-control " value="<?php echo $price;?>" required>
                            </div>

                             <div class="form-group">
                              <label> Category Id</label>
                              <select name="cat_id" class="form-control">

                                     <?php 

                                        include('connection.php');

                                        $query = "SELECT * FROM category";

                                        $result = mysqli_query($conn, $query);

                                        while($row = mysqli_fetch_array($result)) 
                                        {
                                        
                                            ?>

                                               <option value="<?= $row['cat_id'];?>" <?= $cat_id == $row['cat_id']  ? 'selected' : '';?>>  <?= $row['cat_name'];?> </option>

                                      <?php
                                            }

                                        ?>
                              
                              </select>
                            </div>

                            <div class="form-group">
                               <label> description</label>
                              <textarea name="description" class="form-control"> <?php echo $description;?> </textarea>
                            </div>

                            <div class="form-group">
                              <label>Upload House Image </label>
                              <input type="file" name="image" value="" class="form-control">
                              <h6 class="mt-2">Old Image</h6>
                              <img src="<?php echo $image; ?>" width="200px">
                            </div>


                        		<div class="mt-4">
                        			<input type="submit" name="" class="btn btn-primary" value="Save">
                        		</div>


                        	</form>


                        </div>
                    </div>


  </div>

<?php  include('footer.php');?>