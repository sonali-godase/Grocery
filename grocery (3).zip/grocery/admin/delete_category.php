<?php

session_start();
include('connection.php');
$cat_id=$_GET['id'];
$query="delete  from category where cat_id=$cat_id";

mysqli_query($conn,$query);
$_SESSION['success'] = "Record Deleted Successfully";

header("location:category_list.php");
?>
