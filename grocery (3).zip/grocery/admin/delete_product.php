<?php

session_start();
include('connection.php');
$product_id=$_GET['id'];
$query="delete  from products where product_id=$product_id";

mysqli_query($conn,$query);
$_SESSION['success'] = "Record Deleted Successfully";
header("location:product_list.php");
?>