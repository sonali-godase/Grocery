<?php

	session_start();

	include 'connection.php';

	$email = $_POST['email'];

	$password = $_POST['password'];

	$query = "SELECT * FROM admin WHERE email = '$email' AND password = '$password'";

	$result = mysqli_query($conn,$query);

	$count = mysqli_num_rows($result);

	if($count>0)
	{
		$_SESSION['admin'] = "admin";
		header("location:dashboard.php");
	}
	else
	{
		$_SESSION['success'] = "Wrong Email or Password";
		header("location:admin_login.php");
	}

?>