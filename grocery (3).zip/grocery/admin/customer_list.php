<?php  include('header.php');?>

                <!-- Begin Page Content -->
                <div class="container-fluid">

                    <!-- Page Heading -->
                    <h1 class="h3 mb-2 text-gray-800">Customer List</h1>
                  
                    <!-- DataTales Example -->
                    <div class="card shadow mb-4">

                         <?php
                                        
                               if(isset($_SESSION['success']))
                                 { ?>
                                   <div class="alert alert-danger m-2">
                                     <strong> <?= $_SESSION['success'];?> </strong>
                                   </div>
                                          
                              <?php unset($_SESSION['success']); }
                                                              
                          ?>
                        <div class="card-header py-3">
                          <div class="row">

                            <div class="col-lg-6"> 
                                  <h6 class="m-0 font-weight-bold text-primary">Customer</h6>         


                            </div>

                     
                          </div>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                    <thead>
                                        <tr>

                                            <th>Id </th>
                                            <th> Name</th>
                                            <th>Email</th>
                                            <th>Mobile</th>
                                            <th>Password </th>
                                            <th>Address</th>
                              
                                           
                                        </tr>
                                    </thead>
                                  
                                   <tbody>

                                    <?php 

                                        include('connection.php');

                                        $query = "SELECT * FROM customer";

                                        $result = mysqli_query($conn, $query);

                                        while($row = mysqli_fetch_assoc($result)) 
                                        {
                                              
                                           

                                            ?>
                                            <tr>
                                                <td> <?php echo $row['cust_id'];?> </td>
                                                 
                                                <td> <?php echo $row['name'];?> </td>
                                                <td> <?php echo $row['email'];?> </td>
                                                <td> <?php echo $row['mobile'];?>  </td>
                                                <td> <?php echo $row['password'];?> </td>
                                                 <td> <?php echo $row['address'];?> </td>
                                              
                                                </tr>

                                        <?php
                                            }

                                        ?>

                                   </tbody>
                                </table>
                            </div>
                        </div>
                    </div>

                </div>
                <!-- /.container-fluid -->

           

<?php  include('footer.php');?>
