<?php  include('header.php');?>


  <div class="container-fluid">

  <h1 class="h3 mb-2 text-gray-800">Add Products</h1>
                  
                    <!-- DataTales Example -->
                    <div class="card shadow mb-4">
                       
                        <div class="card-body">

                        	<form action="add_product_code.php" method="post"   enctype="multipart/form-data">
                        		
                        		<div class="form-group">
                        			<label> Products name</label> 
                        			<input type="text" name="title" class="form-control" required>
                        		</div>

                            <div class="form-group">
                              <label> Price</label>
                              <input type="text" name="price" class="form-control" required>
                            </div>
                            <div class="form-group">
                              <label> Category Id</label>
                              <select name="cat_id" class="form-control">

                                     <?php 

                                        include('connection.php');

                                        $query = "SELECT * FROM category";

                                        $result = mysqli_query($conn, $query);

                                        while($row = mysqli_fetch_array($result)) 
                                        {
                                        
                                            ?>

                                               <option value="<?= $row['cat_id'];?>">  <?= $row['cat_name'];?> </option>

                                      <?php
                                            }

                                        ?>
                              
                              </select>
                            </div>
                            <div class="form-group">
                              <label> Description</label>
                              <textarea class="form-control" name="description">  </textarea>
                            </div>


                            <div class="form-group">
                              <label>Upload Image </label>
                              <input type="file" name="image" class="form-control">
                            </div>

                        		<div class="mt-4">
                        			<input type="submit" name="" class="btn btn-primary" value="Save">
                        		</div>


                        	</form>


                        </div>
                    </div>


  </div>

<?php  include('footer.php');?>