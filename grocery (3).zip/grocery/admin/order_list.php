<?php  include('header.php');?>

                <!-- Begin Page Content -->
                <div class="container-fluid">

                    <!-- Page Heading -->
                    <h1 class="h3 mb-2 text-gray-800">Order List</h1>
                  
                    <!-- DataTales Example -->
                    <div class="card shadow mb-4">

                         <?php
                                        
                               if(isset($_SESSION['success']))
                                 { ?>
                                   <div class="alert alert-danger m-2">
                                     <strong> <?= $_SESSION['success'];?> </strong>
                                   </div>
                                          
                              <?php unset($_SESSION['success']); }
                                                              
                          ?>
                        <div class="card-header py-3">
                          <div class="row">

                            <div class="col-lg-6"> 
                                  <h6 class="m-0 font-weight-bold text-primary">Orders</h6>         


                            </div>

                          </div>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                    <thead>
                                        <tr>                              
                                             <th>Order ID</th>
                                             <th>Customer</th>
                                             <th>Image</th>
                                            <th>Product</th>
                                            <th>Date</th>
                                            <th>Items</th>
                                            <th>Status</th>
                                            <th>Amount</th>
                                        </tr>
                                    </thead>
                                  
                                   <tbody>

                                    <?php 
                                          include('connection.php');
                                        $query = "SELECT * FROM orders";
                                        $result = mysqli_query($conn,$query);

                                        while ($row = mysqli_fetch_array($result)) 
                                        {

                                        $query1 = "SELECT * FROM products WHERE product_id = " . $row['product_id'];
                                        $result1 = mysqli_query($conn,$query1);
                                        $row1 = mysqli_fetch_array($result1);

                                        $title  =  $row1['title'];
                                        $price  =  $row1['price'];
                                        $image  =  $row1['image'];
                                          


                                          $query2 = "SELECT * FROM customer WHERE cust_id = " . $row['cust_id'];
                                        $result1 = mysqli_query($conn,$query2);
                                        $row2 = mysqli_fetch_array($result1);

                                        $name  =  $row2['name'];
                                        $email  =  $row2['email'];
                                        $mobile  =  $row2['mobile']; 
                                        $address  =  $row2['address'];  
                                 ?>
                                 <tr>
                                     <td class="">
                                       <?=  $date=  $row['order_id'];?>
                                     </td>
                                      <td><?php
                                              echo $name."<br>";
                                              echo $email."<br>";
                                              echo $mobile."<br>";
                                              echo $address."<br>"; 
                                            ?>
                                      </td>
                                    <td class="">
                                       <a href="#"><img src="<?= $image;?>" alt="Ecommerce" class="img-fluid" width="70px"></a>
                                    </td>
                                    <td class="">
                                          <h6 class="mb-0"><?= $title;?> </h6>
                                       
                                       <span><small class="text-muted">₹ <?= $price;?></small></span>
                                    </td>
                                    <td class=""><?=  $row['date'];?></td>
                                    <td class=""><?=  $row['qty'];?></td>
                                    <td class="">

                                      <?php 
                                          if($row['status']=="In process") 
                                          {
                                            ?>
                                               <span class="badge bg-warning text-white"><?=  $row['status'];?>
                                                </span>
                                               <a href="update_order.php?order_id=<?=  $row['order_id'];?>"> Update </a> 
                                         <?php }

                                      ?>

                                      <?php 
                                          if($row['status']=="Completed") 
                                          {
                                            ?>
                                               <span class="badge bg-success text-white"><?=  $row['status'];?>
                                                </span>
                                               <a href="update_order.php?order_id=<?= $row['order_id'];?>&status=Completed"> Update </a> 
                                         <?php }

                                      ?>

                                      
                                    </td>
                                    <td class="">₹ <?=  $row['total'];?></td>
                                 
                                 </tr>

                                 <?php 
                                    }
                                 ?>
                                   
                                   </tbody>
                                </table>
                            </div>
                        </div>
                    </div>

                </div>
                <!-- /.container-fluid -->

           

<?php  include('footer.php');?>
