<?php 

session_start();

?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Add Book</title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<script type="text/javascript" src="js/bootstrap.bundle.js"></script>
	<link rel="stylesheet" type="text/css" href="icons/css/font-awesome.min.css">
</head>
<body style="background:linear-gradient(white,skyblue);">

	
	<div class="masthead" style="background-image: url(Images/pic-3.jpg); background-repeat: no-repeat; background-size: cover; min-height: 50px;">
		<div class="has-bg-img">
			<div class="container-fluid p-4" style="min-height:600px">
				<div class="row justify-content-center">
					<div class="col-lg-4 p-3 mt-5 card border border-3 border-danger shadow-lg bg-light">
						<h3 class="text-center text-danger">Login</h3>
						<?php

						if (isset($_SESSION['success'])) 
						{
							
							?>

							<div class="alert alert-danger text-center">
								<b>
									<?php echo $_SESSION['success']; ?>
								</b>
							</div>

							<?php 
							
						}
						session_destroy();

						?>
						<form action="admin_login_code.php" method="post">
							<div class="mt-3">
								<label>Enter Email: </label>
								<input type="text" name="email" class="form-control" value="" required>
							</div>
							<div class="mt-4">
								<label>Enter Password: </label>
								<input type="password" name="password" class="form-control" value="" required>
							</div>
							<button class="btn btn-success mt-4">Login</button>
						</form>
						<br>

						<a href="../index.php"> Go to Website</a>
					</div>
				</div>
			</div>
		</div>
	</div>

	<?php include('footer.php'); ?>