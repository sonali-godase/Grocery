<?php

	session_start();
 	include('connection.php');


	$cat_name = $_POST['cat_name'];
	
	
	$query = "INSERT INTO category(cat_name) VALUES('$cat_name')";
	mysqli_query($conn, $query);

	$_SESSION['success'] = "Record Added Successfully";
	header("location:category_list.php");

?>