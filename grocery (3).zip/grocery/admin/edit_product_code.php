<?php

session_start();
include('connection.php');
$product_id=$_POST['product_id'];
$title=$_POST['title'];
$price=$_POST['price'];
$cat_id=$_POST['cat_id'];
$description=$_POST['description']; 


    $filename=$_FILES['image']['name'];       // Get file name

    if ($filename == "")   // Check if Image not uploaded
    {
        
       $query="UPDATE products set title='$title', price='$price', cat_id='$cat_id', description='$description' where product_id='$product_id'";
    }
    else
    {        // Check if Image uploaded

        $tmp_name = $_FILES['image']['tmp_name'];   // for temporary Location
        $folder = "upload/".$filename;        // set folder path
        move_uploaded_file($tmp_name, $folder);     // Upload file into folder

         $query="UPDATE products set title='$title', price='$price', cat_id='$cat_id', description='$description', image='$folder' where product_id='$product_id'";
    } 

	mysqli_query($conn,$query);
	$_SESSION['success'] = "Record Updated Successfully";
	header("location:product_list.php");
?>