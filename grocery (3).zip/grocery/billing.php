<?php include("header.php");
require("admin/connection.php"); 

if(!isset($_SESSION['customer']))
{ 
	header("Locations:login.php");
}


$cust_id = $_SESSION['cust_id'];

$query = "SELECT * FROM customer WHERE cust_id = " . $cust_id;
$result = mysqli_query($conn,$query);
$row = mysqli_fetch_array($result);

$name  =  $row['name'];
$mobile=  $row['mobile'];
$email=  $row['email'];
$address =  $row['address'];



$product_id = $_GET['product_id'];

$query1 = "SELECT * FROM products WHERE product_id = " . $product_id;
$result1 = mysqli_query($conn,$query1);
$row1 = mysqli_fetch_array($result1);

$title  =  $row1['title'];
$price=  $row1['price'];
$image=  $row1['image'];

?>


<main>

	<section class="mb-lg-14 mb-8 mt-8">
		<div class="container">
			<!-- row -->
			<div class="row">
				<!-- col -->
				<div class="col-12">
					<div>
						<div class="mb-8">
							<!-- text -->
							<h1 class="fw-bold mb-0">Billing Details</h1>

						</div>
					</div>
				</div>
			</div>
			<div>
				<!-- row -->
				<div class="row">
					<div class="col-lg-5 col-md-12">
						<!-- accordion -->
						<div class="card shadow-sm p-3">
							<h5> Name - <?= $name;?> </h5>	
							<h5> Email- <?= $email;?> </h5>	
							<h5> Mobile - <?= $mobile;?> </h5>	
							<h5> Address - <?= $address;?> </h5>	
						</div>
					</div>

					<div class="col-lg-7">
						<form action="billing_code.php" method="post"> 
							<div class="mt-4 mt-lg-0">
								<div class="card shadow-sm">
									<h5 class="px-6 py-4 bg-transparent mb-0">Order Details</h5>

									<ul class="list-group list-group-flush">
										<!-- list group -->
										<li class="list-group-item py-3 ps-0 border-top">
											<!-- row -->
											<div class="row align-items-center">
												<div class="col-md-2 text-center">
													<img src="admin/<?= $image;?>" alt="Ecommerce" class="img-fluid p-1">
												</div>

												<div class="col-4 col-md-4 col-lg-5">
													<div class="d-flex">

														<div class="ms-3">
															<!-- title -->
															<a href="#" class="text-inherit">
																<h6 class="mb-0"><?= $title;?></h6>
															</a>
															<span><small class="text-muted">₹ <span id="price"><?= $price;?></span> </small></span>
															<!-- text -->
															
														</div>
													</div>
												</div>
												<!-- input group -->
												<div class="col-4 col-md-4 col-lg-3">
													<!-- input -->
													<!-- input -->
													<div class="input-group input-spinner">
														 <input type="button" value="-" class="button-minus btn btn-sm" data-field="quantity" onclick="subtotal22()"> 
														
														<input type="number" step="1" max="10" min="1" value="1" name="quantity" id="quantity" class="quantity-field form-control-sm form-input" onchange="suntotal1(this.value)">

														<input type="button" value="+" class="button-plus btn btn-sm" data-field="quantity" onclick="subtotal()">


													</div>
												</div>
												<!-- price -->
												<div class="col-2 text-lg-end text-start text-md-end col-md-2">
													₹<span class="fw-bold" id="total"></span>

													<input type="hidden" name="cust_id" value="<?= $cust_id;?>">	
													<input type="hidden" name="product_id" value="<?= $product_id;?>">
													<input type="hidden" name="final_total" id="final_total" value="">
												</div>


											</div>
										</li>
										<!-- list group -->

									</ul>
								</div>
								<div class="text-right">
									<input type="checkbox" class="mt-5" name="" checked disabled=""> Cash on Delivery <br>
									<button type="submit" class="btn btn-primary mt-3">Place Order</button>
								</div>

							</div>

							</form>
					</div>
				</div>
			</div>
		</div>
	</section>
</main>

<script type="text/javascript">
	
	function subtotal22()
	{


		var q = document.getElementById("quantity").value;
		var p = document.getElementById("price").innerText;

		q--;
		var total= q*p;

		// alert(total);

		document.getElementById("total").innerText = total;

		document.getElementById("final_total").value = total;

	}

	
	function subtotal()
	{


		var q = document.getElementById("quantity").value;
		var p = document.getElementById("price").innerText;

		q++;
		var total= q*p;

		// alert(total);

		document.getElementById("total").innerText = total;

		document.getElementById("final_total").value = total;

	}


		function subtotal2()
	{


		var q = 1;
		var p = document.getElementById("price").innerText;

	
		var total= q*p;

		// alert(total);

		document.getElementById("total").innerText = total;

		document.getElementById("final_total").value = total;

	}



	subtotal2();

	function suntotal1(q)
	{


		var p = document.getElementById("price").innerText;

		var total= q*p;

		// alert(total);

		document.getElementById("total").innerText = total;
		document.getElementById("final_total").value = total;	

	}


</script>

<?php include("footer.php");?>