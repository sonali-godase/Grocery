

<?php include("header.php");?>

<main>
   <!-- section -->

   <section class="my-lg-14 my-8">
      <!-- container -->
      <div class="container">
         <!-- row -->
         <div class="row justify-content-center align-items-center">
            <div class="col-12 col-md-6 col-lg-4 order-lg-1 order-2">
               <!-- img -->
               <img src="assets/images/svg-graphics/signup-g.svg" alt="" class="img-fluid">
            </div>
            <!-- col -->
            <div class="col-12 col-md-6 offset-lg-1 col-lg-4 order-lg-2 order-1">
               <div class="mb-lg-9 mb-5">
              
               <h5>Congratulation....!!  Order placed Successfully...<br>
                  your order will be recieved on Date 4-5 Working days
               <br> <br> 

                  <a href="orders.php" class="btn btn-primary mt-4"> View Order Status  </a> </p> </h5>
            </div>
            <!-- form -->
       
         </div>
      </div>
   </div>
</section>
</main>


<?php include("footer.php");?>