
<?php 
session_start();
?>

<?php include("admin/connection.php");?>

<!DOCTYPE html>
<html lang="en">

<!-- Mirrored from freshcart.codescandy.com/pages/index-4.html by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 18 Mar 2024 09:02:17 GMT -->
<head>
	<!-- Required meta tags -->
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<meta content="Codescandy" name="author">
	<title>Grocery</title>
	<link href="assets/libs/tiny-slider/dist/tiny-slider.css" rel="stylesheet" />
	<link href="assets/libs/slick-carousel/slick/slick.css" rel="stylesheet" />
	<link href="assets/libs/slick-carousel/slick/slick-theme.css" rel="stylesheet" />
	<!-- Favicon icon-->
	<link rel="shortcut icon" type="image/x-icon" href="assets/images/favicon/favicon.ico">


	<!-- Libs CSS -->
	<link href="assets/libs/bootstrap-icons/font/bootstrap-icons.min.css" rel="stylesheet">
	<link href="assets/libs/feather-webfont/dist/feather-icons.css" rel="stylesheet">
	<link href="assets/libs/simplebar/dist/simplebar.min.css" rel="stylesheet">


	<!-- Theme CSS -->
	<link rel="stylesheet" href="assets/css/theme.min.css">
	<script async src="https://www.googletagmanager.com/gtag/js?id=G-M8S4MT3EYG"></script>
	<script>
		window.dataLayer = window.dataLayer || [];
		function gtag() {
			dataLayer.push(arguments);
		}
		gtag("js", new Date());

		gtag("config", "G-M8S4MT3EYG");
	</script>
	<script type="text/javascript">
		(function (c, l, a, r, i, t, y) {
			c[a] =
			c[a] ||
			function () {
				(c[a].q = c[a].q || []).push(arguments);
			};
			t = l.createElement(r);
			t.async = 1;
			t.src = "https://www.clarity.ms/tag/" + i;
			y = l.getElementsByTagName(r)[0];
			y.parentNode.insertBefore(t, y);
		})(window, document, "clarity", "script", "kuc8w5o9nt");
	</script>

</head>
<body style="background:linear-gradient(pink,skyblue);">
	<!-- navigation -->
	<header class="py-lg-5 py-4 border-bottom border-bottom-lg-0 align-items-center justify-content-center shadow bg-warning bg-gradient">
		<div class="container">
			<div class="row w-100 align-items-center gx-3">
				<div class="col-lg-3">
					<div class="align-items-center">
						<h2> E-Grocery Shop</h2>
					</div>

				</div>

				<div class="col-lg-4">

					<form action="all_product.php" method="GET"  class="w-100 d-none d-lg-block">
						<div class="input-group">
							<input class="form-control rounded" type="search" placeholder="Search for products" name="search" value="<?= isset($_GET['search']) ? $_GET['search'] : '';?>">
							<span class="input-group-append">
								<button type="submit" class="btn bg-white border">
									Search
								</button>
							</span>
						</div>
					</form>

				</div>
				<div class="col-lg-5">
					<div class="list-inline ms-auto d-lg-block d-none">

						<div class="list-inline-item me-3">
							<a href="all_product.php" class="text-reset" >All Products</a>
						</div>
						
							<div class="list-inline-item me-3">
							<a href="index.php" class="text-reset" >Home</a>
						</div>
							
							<div class="list-inline-item me-3">
							<a href="about.php" class="text-reset" >About</a>
						</div>
					


						<?php 

						if(!isset($_SESSION['customer']))
							{ ?>

								<div class="list-inline-item me-3">
									<a href="register.php" class="text-reset" >Register</a>
								</div>

								<div class="list-inline-item">
									<a href="login.php" class="btn btn-dark d-none d-xl-block">Sign In</a>
								</div>


								<?php 
							}
							else
							{
								?>

								<div class="list-inline-item me-3">
									<a href="profile.php" class="text-reset" >Profile</a>
								</div>

								<div class="list-inline-item">
									<a href="logout.php" class="btn btn-dark d-none d-xl-block">Logout</a>
								</div>



							<?php }?>
						</div>
					</div>
				</div>
			</div>
		</header>


		

