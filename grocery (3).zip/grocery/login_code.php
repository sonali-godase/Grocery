<?php

	session_start();

	include 'admin/connection.php';

	$email = $_POST['email'];

	$password = $_POST['password'];

	$query = "SELECT * FROM customer WHERE email = '$email' AND password = '$password'";

	$result = mysqli_query($conn,$query);

	$count = mysqli_num_rows($result);


	if($count>0)
	{

		 $data = mysqli_fetch_assoc($result);
		 $cust_id = $data['cust_id'];

		 $_SESSION['cust_id'] = $cust_id;

		 // echo $_SESSION['cust_id'];
		 // exit;
		
		$_SESSION['customer'] = "customer";
		header("location:index.php");
	}
	else
	{
		$_SESSION['success'] = "Wrong Email or Password";

		// echo $_SESSION['success'];exit;

		header("location:login.php");
	}

?>