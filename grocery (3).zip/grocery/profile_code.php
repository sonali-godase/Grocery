<?php
    
        session_start();
        require("admin/connection.php");

        $cust_id = $_SESSION['cust_id'];
        $name = $_POST['name'];
        $mobile = $_POST['mobile'];
        $email = $_POST['email'];
        $address = $_POST['address'];
                   
        $query = "UPDATE customer SET name = '$name', mobile= '$mobile', email = '$email', address = '$address' ";
        $query .= "WHERE cust_id = ".$cust_id;

      
        mysqli_query($conn, $query);

      
        $_SESSION['success'] = "Profile Updated...!!";     
        header("Location:profile.php");
        
        

?>