<?php include("header.php");

$cat_id=$_GET['cat_id'];
$query="SELECT * FROM category WHERE cat_id='$cat_id'";
$result =mysqli_query($conn,$query);
$data=mysqli_fetch_assoc($result);
$cat_name=$data["cat_name"];

?>
<main>

	<div class="mt-8 mb-lg-14 mb-8">
		<!-- container -->
		<div class="container">
			<!-- row -->
			<div class="row gx-10">
				<!-- col -->

				<section class="col-lg-12 col-md-12">
					<!-- card -->
					<div class="card mb-4 bg-light border-0">
						<!-- card body -->
						<div class="card-body p-9">
							<h2 class="mb-0 fs-1"><?= $cat_name;?></h2>
						</div>
					</div>
					<!-- list icon -->

					<!-- row -->
					<div class="row g-4 row-cols-xl-4 row-cols-lg-3 row-cols-2 row-cols-md-2 mt-2">
						<!-- col -->
						<?php 
						$query = "SELECT * FROM products WHERE cat_id=$cat_id";

						$result = mysqli_query($conn, $query);

						while($row = mysqli_fetch_array($result)) 
						{

							?>

							<div class="col">
								<!-- card -->
								<div class="card card-product">
									<div class="card-body">
										<!-- badge -->
										<div class="text-center position-relative">
											<a href="product_detail.php?product_id=<?= $row['product_id'];?>"><img src="admin/<?= $row['image'];?>" alt="Grocery Ecommerce Template" class="mb-3 img-fluid"></a>
											<!-- action btn -->
										
										</div>
										<!-- heading -->
										<div class="text-small mb-1">
											<a href="#!" class="text-decoration-none text-muted"><small>
												<?= $cat_name;?>
											</small></a>
										</div>
										<h2 class="fs-6"><a href="shop-single.html" class="text-inherit text-decoration-none"><?= $row['title'];?></a></h2>
									
										<!-- price -->
										<div class="d-flex justify-content-between align-items-center mt-3">
											<div>
												<span class="text-dark">₹ <?= $row['price'];?></span>
											</div>
											<!-- btn -->
											<div>
												<a href="product_detail.php?product_id=<?php echo $row['product_id'];?>" class="btn btn-primary btn-sm">
													<i class="bi bi-eye"> </i>
													view
												</a>
											</div>
										</div>
									</div>
								</div>
							</div>
							<?php 
						}
						?>
					</div>

				</section>
			</div>
		</div>
	</div>
</main>

<?php include("footer.php");?>