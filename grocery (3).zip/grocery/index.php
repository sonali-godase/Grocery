<?php include("header.php");?>
<!-- Modal -->


<main  >


		<section class="mb-lg-10 mt-lg-14 my-8">
				<div class="container">
					<div class="row">
						<div class="col-12 mb-6">
							<h3 class="mb-0">Grocery Category</h3>
						</div>
					</div>
					<div class="category-slider">


								<?php 

								$query = "SELECT * FROM category";

								$result = mysqli_query($conn, $query);

								while($row = mysqli_fetch_array($result)) 
								{

									?>

						<div class="item">
							<a href="product_list.php?cat_id=<?= $row['cat_id'];?>" class="text-decoration-none text-inherit">
								<div class="card card-product mb-lg-4">
									<div class="card-body text-center">
										
										<div class="text-truncate">
											<h2><?= $row['cat_name'];?></h2>

										</div>
									</div>
								</div>
							</a>
						</div>

							<?php 
										}
							?>

						
					</div>
				</div>
			</section>


	<section class="mb-lg-14 my-8">
		<div class="container">
			<!-- row -->
			<div class="row align-items-center mb-6">
				<div class="col-lg-10 col-9">
					<div class="d-xl-flex justify-content-between align-items-center">
						<!-- heading -->
						<div class="d-flex">
							<div class="mt-1">
								<svg
								xmlns="http://www.w3.org/2000/svg"
								width="24"
								height="24"
								viewBox="0 0 24 24"
								fill="none"
								stroke="currentColor"
								stroke-width="2"
								stroke-linecap="round"
								stroke-linejoin="round"
								class="feather feather-shopping-bag text-primary"
								>
								<path d="M6 2L3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z"></path>
								<line x1="3" y1="6" x2="21" y2="6"></line>
								<path d="M16 10a4 4 0 0 1-8 0"></path>
							</svg>
						</div>
						<div class="ms-3">
							<h3 class="mb-0"> Products List</h3>
						</div>
					</div>
				</div>
			</div>
			<div class="col-lg-2 col-3">
				<div class="slider-arrow" id="slider-third-arrows"></div>
			</div>
		</div>
		<!-- row -->
		<div class="row">
			<div class="col-12">
				<div class="product-slider-second" id="slider-third">
					<!-- item -->

					<?php 
					$query = "SELECT * FROM products";

					$result = mysqli_query($conn, $query);

					while($row = mysqli_fetch_array($result)) 
					{

						?>

						<div class="item">
							<!-- card -->
							<div class="card card-product h-100 mb-4">
								<div class="card-body position-relative text-center">
									<!-- badge -->
									<div class="text-center position-relative">

										<!-- img -->
										<a href="product_detail.php?product_id=<?= $row['product_id'];?>"><img src="admin/<?= $row['image'];?>" alt="Grocery Ecommerce Template" class="mb-3 img-fluid" /></a>
										<!-- action btn -->

									</div>
									<!-- title -->
									<h2 class="fs-6"><a href="product_detail.php?product_id=<?= $row['product_id'];?>" class="text-inherit text-decoration-none"><?= $row['title'];?></a></h2>

									<!-- price -->
									<div class="justify-content-between align-items-center mt-3 text-center">
										<div class="text-center">
											<span class="text-danger">₹<?= $row['price'];?></span>
										</div>
									</div>
									<div class="d-grid mt-4">
										<a href="product_detail.php?product_id=<?= $row['product_id'];?>" class="btn btn-primary rounded-pill">View</a>
									</div>
								</div>
							</div>
						</div>

						<?php 
					}
					?>
				</div>
			</div>
		</div>
	</div>
</section>


<section class="my-lg-14 my-8">
	<div class="container">
		<div class="row align-items-center">
			<!-- col -->
			<div class="col-lg-4 col-md-6 col-12">
				<div class="mb-6 border-end-lg p-md-4 px-xl-12 text-center">
					<div>
						<!-- text -->
						<div class="mb-8">
							<!-- svg -->
							<svg xmlns="http://www.w3.org/2000/svg" width="34" height="34" fill="currentColor" class="bi bi-clock text-primary" viewBox="0 0 16 16">
								<path d="M8 3.5a.5.5 0 0 0-1 0V9a.5.5 0 0 0 .252.434l3.5 2a.5.5 0 0 0 .496-.868L8 8.71V3.5z" />
								<path d="M8 16A8 8 0 1 0 8 0a8 8 0 0 0 0 16zm7-8A7 7 0 1 1 1 8a7 7 0 0 1 14 0z" />
							</svg>
						</div>
						<!-- text -->
						<h3 class="fs-5 mb-3">Cheapest basket 25 years running</h3>
						<p class="mb-0">Get your order delivered to your doorstep at the earliest from FreshCart pickup stores near you.</p>
					</div>
				</div>
			</div>
			<div class="col-lg-4 col-md-6 col-12">
				<div class="mb-6 border-end-lg p-md-4 px-xl-12 text-center">
					<div>
						<div class="mb-8">
							<!-- svg -->
							<svg xmlns="http://www.w3.org/2000/svg" width="34" height="34" fill="currentColor" class="bi bi-gift text-primary" viewBox="0 0 16 16">
								<path
								d="M3 2.5a2.5 2.5 0 0 1 5 0 2.5 2.5 0 0 1 5 0v.006c0 .07 0 .27-.038.494H15a1 1 0 0 1 1 1v2a1 1 0 0 1-1 1v7.5a1.5 1.5 0 0 1-1.5 1.5h-11A1.5 1.5 0 0 1 1 14.5V7a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1h2.038A2.968 2.968 0 0 1 3 2.506V2.5zm1.068.5H7v-.5a1.5 1.5 0 1 0-3 0c0 .085.002.274.045.43a.522.522 0 0 0 .023.07zM9 3h2.932a.56.56 0 0 0 .023-.07c.043-.156.045-.345.045-.43a1.5 1.5 0 0 0-3 0V3zM1 4v2h6V4H1zm8 0v2h6V4H9zm5 3H9v8h4.5a.5.5 0 0 0 .5-.5V7zm-7 8V7H2v7.5a.5.5 0 0 0 .5.5H7z"
								/>
							</svg>
						</div>
						<!-- text -->
						<h3 class="fs-5 mb-3">Best Prices & Offers</h3>
						<p class="mb-0">Cheaper prices than your local supermarket, great cashback offers to top it off.</p>
					</div>
				</div>
			</div>
			<div class="col-lg-4 col-md-6 col-12">
				<div class="mb-6 p-md-4 px-xl-12 text-center">
					<div>
						<div class="mb-8">
							<!-- svg -->
							<svg xmlns="http://www.w3.org/2000/svg" width="34" height="34" fill="currentColor" class="bi bi-box-seam text-primary" viewBox="0 0 16 16">
								<path
								d="M8.186 1.113a.5.5 0 0 0-.372 0L1.846 3.5l2.404.961L10.404 2l-2.218-.887zm3.564 1.426L5.596 5 8 5.961 14.154 3.5l-2.404-.961zm3.25 1.7-6.5 2.6v7.922l6.5-2.6V4.24zM7.5 14.762V6.838L1 4.239v7.923l6.5 2.6zM7.443.184a1.5 1.5 0 0 1 1.114 0l7.129 2.852A.5.5 0 0 1 16 3.5v8.662a1 1 0 0 1-.629.928l-7.185 2.874a.5.5 0 0 1-.372 0L.63 13.09a1 1 0 0 1-.63-.928V3.5a.5.5 0 0 1 .314-.464L7.443.184z"
								/>
							</svg>
						</div>
						<!-- text -->
						<h3 class="fs-5 mb-3">Wide Assortment</h3>
						<p class="mb-0">Choose from 5000+ products across food, personal care, household & other categories</p>
					</div>
				</div>
			</div>
			<div class="col-12 d-md-none d-lg-block">
				<!-- hr -->
				<hr class="mt-8 mb-10" />
			</div>
			<div class="col-lg-4 col-md-6 col-12">
				<!-- text -->
				<div class="mb-6 border-end-lg p-md-4 px-xl-12 text-center">
					<div>
						<div class="mb-8">
							<!-- svg -->
							<svg xmlns="http://www.w3.org/2000/svg" width="34" height="34" fill="currentColor" class="bi bi-tablet text-primary" viewBox="0 0 16 16">
								<path d="M12 1a1 1 0 0 1 1 1v12a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1h8zM4 0a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h8a2 2 0 0 0 2-2V2a2 2 0 0 0-2-2H4z" />
								<path d="M8 14a1 1 0 1 0 0-2 1 1 0 0 0 0 2z" />
							</svg>
						</div>
						<!-- text -->
						<h3 class="fs-5 mb-3">Shop with our app</h3>
						<p class="mb-0">
							Shop on the go with our app for
							<a href="#">tablet and mobile</a>
							. Get live order tracking. Get latest feature updates
						</p>
					</div>
				</div>
			</div>
			<div class="col-lg-4 col-md-6 col-12">
				<div class="mb-6 border-end-lg p-md-4 px-xl-12 text-center">
					<div>
						<div class="mb-8">
							<!-- svg -->
							<svg xmlns="http://www.w3.org/2000/svg" width="34" height="34" fill="currentColor" class="bi bi-truck text-primary" viewBox="0 0 16 16">
								<path
								d="M0 3.5A1.5 1.5 0 0 1 1.5 2h9A1.5 1.5 0 0 1 12 3.5V5h1.02a1.5 1.5 0 0 1 1.17.563l1.481 1.85a1.5 1.5 0 0 1 .329.938V10.5a1.5 1.5 0 0 1-1.5 1.5H14a2 2 0 1 1-4 0H5a2 2 0 1 1-3.998-.085A1.5 1.5 0 0 1 0 10.5v-7zm1.294 7.456A1.999 1.999 0 0 1 4.732 11h5.536a2.01 2.01 0 0 1 .732-.732V3.5a.5.5 0 0 0-.5-.5h-9a.5.5 0 0 0-.5.5v7a.5.5 0 0 0 .294.456zM12 10a2 2 0 0 1 1.732 1h.768a.5.5 0 0 0 .5-.5V8.35a.5.5 0 0 0-.11-.312l-1.48-1.85A.5.5 0 0 0 13.02 6H12v4zm-9 1a1 1 0 1 0 0 2 1 1 0 0 0 0-2zm9 0a1 1 0 1 0 0 2 1 1 0 0 0 0-2z"
								/>
							</svg>
						</div>
						<!-- text -->
						<h3 class="fs-5 mb-3">Want your shopping today?</h3>
						<p class="mb-0">
							Choose from our award winning
							<a href="#">Express delivery</a>
							or collection options.
						</p>
					</div>
				</div>
			</div>
			<div class="col-lg-4 col-md-6 col-12">
				<div class="mb-6 p-md-4 px-xl-12 text-center">
					<div>
						<div class="mb-8">
							<!-- svg -->
							<svg xmlns="http://www.w3.org/2000/svg" width="34" height="34" fill="currentColor" class="bi bi-arrow-repeat text-primary" viewBox="0 0 16 16">
								<path
								d="M11.534 7h3.932a.25.25 0 0 1 .192.41l-1.966 2.36a.25.25 0 0 1-.384 0l-1.966-2.36a.25.25 0 0 1 .192-.41zm-11 2h3.932a.25.25 0 0 0 .192-.41L2.692 6.23a.25.25 0 0 0-.384 0L.342 8.59A.25.25 0 0 0 .534 9z"
								/>
								<path
								fill-rule="evenodd"
								d="M8 3c-1.552 0-2.94.707-3.857 1.818a.5.5 0 1 1-.771-.636A6.002 6.002 0 0 1 13.917 7H12.9A5.002 5.002 0 0 0 8 3zM3.1 9a5.002 5.002 0 0 0 8.757 2.182.5.5 0 1 1 .771.636A6.002 6.002 0 0 1 2.083 9H3.1z"
								/>
							</svg>
						</div>
						<!-- text -->
						<h3 class="fs-5 mb-3">Easy Returns/Refund</h3>
						<p class="mb-0">
							Not satisfied with a product? Return it at the doorstep & get a refund within hours. No questions asked
							<a href="#">policy</a>
							.
						</p>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>

</main>
<!-- modal -->

<!-- Footer -->



<?php include("footer.php");?>