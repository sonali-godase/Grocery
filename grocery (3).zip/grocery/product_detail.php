<?php include("header.php");

$product_id=$_GET['product_id'];
$query="SELECT * FROM products WHERE product_id='$product_id'";
$result =mysqli_query($conn,$query);
$data=mysqli_fetch_assoc($result);

?>
<main>

	<div class="mt-8 mb-lg-14 mb-8">
		<!-- container -->
		<div class="container">
			<!-- row -->
			<div class="row gx-10">
				<!-- col -->

				<section class="col-lg-12 col-md-12">
					<!-- card -->
					<div class="card mb-4 bg-light border-0">
						<!-- card body -->
						<div class="card-body p-9">
							<h2 class="mb-0 fs-1"><?= $data['title'];?></h2>
						</div>
					</div>
					<!-- list icon -->

					<!-- row -->
					<div class="container">
						<div class="row">
							<div class="col-md-5 col-xl-6">
								<!-- img slide -->
								<div class="tns-outer" id="product-ow">
									<img src="admin/<?= $data['image'];?>" alt="" class="img-fluid">

								</div>
							</div>
							<div class="col-md-7 col-xl-6">
								<div class="ps-lg-10 mt-6 mt-md-0">
									<!-- content -->

									<!-- heading -->
									<h1 class="mb-1"><?= $data['title'];?></h1>
									
									<div class="fs-4">
										<!-- price -->
										<span class="fw-bold text-dark">₹ <?= $data['price'];?></span>
									</div>
									<!-- hr -->
									<hr class="my-6">
									
									
									<!-- hr -->
									<div>
										<?= $data['description'];?>
										
									</div>

									<div class="mt-3 row justify-content-start g-2 align-items-center">
										<div class="col-xxl-4 col-lg-4 col-md-5 col-5 d-grid">
											<!-- button -->
											<!-- btn -->


											<?php

											if(!isset($_SESSION['customer']))
											{
												echo "<a href='login.php' class='btn btn-primary'>
												<i class='feather-icon icon-shopping-bag me-2'></i>
												Buy Now
													</a>";
											}
											else
											{
														echo "<a href='billing.php?product_id=$product_id' class='btn btn-primary'>
												<i class='feather-icon icon-shopping-bag me-2'></i>
												Buy Now
													</a>";	
											}

											?>

										</div>

									</div>
								</div>
							</div>
						</div>

							<hr>

							<div class="row">
							

							<div class="col-md-6 mt-5">
								<div class="mb-10">
									<div class="d-flex justify-content-between align-items-center mb-8">
										<div>
											<!-- heading -->
											<h4>Reviews</h4>
										</div>

									</div>
 								<?php 

								

                                        $query = "SELECT *,(SELECT name FROM customer WHERE customer.cust_id = review.cust_id) AS cust_name FROM review WHERE product_id =$product_id";
                                        // echo $query;
                                        // exit;

                                        $result = mysqli_query($conn, $query);

                                        $row_count = mysqli_num_rows($result); 
                                        if ($row_count>0) 
                                        {
                                        	
                                        while($row = mysqli_fetch_assoc($result)) 
                                        {
                                        	?>
									<div class="d-flex border-bottom pb-6 mb-6">
									
										<div class="ms-5">
											<h6 class="mb-1"><?= $row['cust_name'];?></h6>
											<!-- select option -->
											<!-- content -->
											<p class="small">
												<span class="text-muted"><?= $row['date'];?></span>
												<span class="text-primary ms-3 fw-bold">Verified Purchase</span>
											</p>
											<!-- rating -->

											<!-- text-->
											<p>
												<?= $row['message'];?>
											</p>

										</div>
									</div>
									  <?php
                                            }
                                        }
                                            else
                                            {
                                            	echo "No product review yet..";
                                            }
                                      
                                        ?>
								</div>

							</div>

							<div class="col-md-6 mt-5">
								<div class="mb-10">
									<div class="d-flex justify-content-between align-items-center mb-8">
										<div>
											<!-- heading -->
											<h4>Write Reviews</h4>
										</div>

									</div>
									<?php 
										if(isset($_SESSION['customer']))
								{
                                 
												$cust_id = $_SESSION['cust_id'];

											?>
									<form action="add_review_code.php" method="post"   enctype="multipart/form-data">

										<input type="hidden" name="cust_id" value="<?= $cust_id;?>">
										<input type="hidden" name="product_id" value="<?= $product_id;?>">
										<div class="form-group">
											<label> Message</label>
											<textarea class="form-control" name="message" required>  </textarea>
										</div>


										
										<div class="mt-4">
											<input type="submit" name="" class="btn btn-primary" value="Submit">
										</div>


									</form>
									<?php 
								}
								else{

								 ?>
								 <p> Login first to write review </p>
								 <a href="login.php" class="btn btn-primary"> 
								 	Login Now
								 </a>
								 <?php 

								}
								?>
								</div>

							</div>

						</div>
					</div>

				</section>
			</div>
		</div>
	</div>
</main>

<?php include("footer.php");?>