<?php include("header.php");
require("admin/connection.php"); 

if(!isset($_SESSION['customer']))
{ 
    header("Locations:login.php");
}


    $cust_id = $_SESSION['cust_id'];

    

?>

<main>
         <!-- section -->
         <section>
            <div class="container">
               <!-- row -->
               <div class="row">
                  <!-- col -->
                  <div class="col-12">
                     <div class="d-flex justify-content-between align-items-center d-md-none py-4">
                        <!-- heading -->
                        <h3 class="fs-5 mb-0">Account Setting</h3>
                        <!-- button -->
                        <button class="btn btn-outline-gray-400 text-muted d-md-none btn-icon btn-sm ms-3" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasAccount" aria-controls="offcanvasAccount">
                           <i class="bi bi-text-indent-left fs-3"></i>
                        </button>
                     </div>
                  </div>
                  <!-- col -->
                  <div class="col-lg-3 col-md-4 col-12 border-end d-none d-md-block">
                     <div class="pt-10 pe-lg-10">
                        <!-- nav -->
                        <ul class="nav flex-column nav-pills nav-pills-dark">
                           <!-- nav item -->
                          <li class="nav-item">
                              <a class="nav-link" href="profile.php">
                                 <i class="feather-icon icon-settings me-2"></i>
                                 Profile
                              </a>
                           </li>
                           <!-- nav item -->
                          
                             <li class="nav-item">
                              <a class="nav-link active" href="orders.php">
                                 <i class="feather-icon icon-shopping-bag me-2"></i>
                                 Orders
                              </a>
                           </li>
                      
                       
                           <!-- nav item -->
                           <li class="nav-item">
                              <hr>
                           </li>
                           <!-- nav item -->
                           <li class="nav-item">
                              <a class="nav-link" href="logout.php">
                                 <i class="feather-icon icon-log-out me-2"></i>
                                 Log out
                              </a>
                           </li>
                        </ul>
                     </div>
                  </div>
                  <div class="col-lg-9 col-md-8 col-12">
                     <div class="py-6 p-md-6 p-lg-10">
                        <!-- heading -->
                        <h2 class="mb-6">Your Orders</h2>

                        <div class="table-responsive-xxl border-0">
                           <!-- Table -->
                           <table class="table mb-0 text-nowrap table-centered">
                              <!-- Table Head -->
                              <thead class="bg-light">
                                 <tr>
                                    <th>Order ID</th>
                                     <th>Image</th>
                                    <th>Product</th>
                                    <th>Date</th>
                                    <th>Items</th>
                                    <th>Status</th>
                                    <th>Amount</th>

                                 </tr>
                              </thead>
                              <tbody>
                                 <!-- Table body -->

                                 <?php 
                                        $query = "SELECT * FROM orders WHERE cust_id = " . $cust_id;
                                        $result = mysqli_query($conn,$query);

                                        while ($row = mysqli_fetch_array($result)) 
                                        {

                                        $query1 = "SELECT * FROM products WHERE product_id = " . $row['product_id'];
                                        $result1 = mysqli_query($conn,$query1);
                                        $row1 = mysqli_fetch_array($result1);

                                        $title  =  $row1['title'];
                                        $price  =  $row1['price'];
                                        $image  =  $row1['image'];
                                          
                                 ?>
                                 <tr>
                                     <td class="align-middle border-top-0 w-0">
                                       <?=  $date=  $row['order_id'];?>
                                     </td>
                                    <td class="align-middle border-top-0 w-0">
                                       <a href="#"><img src="admin/<?= $image;?>" alt="Ecommerce" class="icon-shape icon-xl"></a>
                                    </td>
                                    <td class="align-middle border-top-0">
                                       <a href="#" class="fw-semibold text-inherit">
                                          <h6 class="mb-0"><?= $title;?> </h6>
                                       </a>
                                       <span><small class="text-muted">₹ <?= $price;?></small></span>
                                    </td>
                                    <td class="align-middle border-top-0"><?=  $row['date'];?></td>
                                    <td class="align-middle border-top-0"><?=  $row['qty'];?></td>
                                    <td class="align-middle border-top-0">
                                       <span class="badge btn btn-<?= $row['status'] == 'Completed' ? 'success' : 'warning';?>"><?=  $row['status'];?></span>
                                    </td>
                                    <td class="align-middle border-top-0">₹ <?=  $row['total'];?></td>
                                 
                                 </tr>

                                 <?php 
                                    }
                                 ?>
                               
                              </tbody>
                           </table>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </section>
      </main>





<?php include("footer.php");
?>