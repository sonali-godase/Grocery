<?php include("header.php");?>

<main>
         <!-- section -->
         <section class="my-lg-14 my-8">
            <div class="container">
               <!-- row -->
               <div class="row justify-content-center align-items-center">
                  <div class="col-12 col-md-6 col-lg-4 order-lg-1 order-2">
                     <!-- img -->
                     <img src="assets/images/svg-graphics/signin-g.svg" alt="" class="img-fluid">
                  </div>
                  <!-- col -->
                  <div class="col-12 col-md-6 offset-lg-1 col-lg-4 order-lg-2 order-1">
                     <div class="mb-lg-9 mb-5">

                        <?php

                  if (isset($_SESSION['success'])) 
                  {
                     
                     ?>

                     <div class="alert alert-danger text-center">
                        <b>
                           <?php echo $_SESSION['success']; ?>
                        </b>
                     </div>

                     <?php 

                     session_destroy();
                     
                  }
                

                  ?>

                        <h1 class="mb-1 h2 fw-bold">Sign in to E-Grocery Shop</h1>
                        <p>Welcome back to E-Grocery Shop! Enter your email to get started.</p>
                     </div>

                     <form class="needs-validation"  action="login_code.php" method="post">
                        <div class="row g-3">
                           <!-- row -->

                           <div class="col-12">
                              <!-- input -->
                              <label for="formSigninEmail" class="form-label visually-hidden">Email address</label>
                              <input type="email" class="form-control" id="formSigninEmail" placeholder="Email" required="" name="email">
                              <div class="invalid-feedback">Please enter name.</div>
                           </div>
                           <div class="col-12">
                              <!-- input -->
                              <div class="password-field position-relative">
                                 <label for="formSigninPassword" class="form-label visually-hidden">Password</label>
                                 <div class="password-field position-relative">
                                    <input type="password" class="form-control fakePassword" id="formSigninPassword" placeholder="*****" required="" name="password">
                                    <span><i class="bi bi-eye-slash passwordToggler"></i></span>
                                    <div class="invalid-feedback">Please enter password.</div>
                                 </div>
                              </div>
                           </div>
                           <!-- btn -->
                           <div class="col-12 d-grid"><button type="submit" class="btn btn-primary">Sign In</button></div>
                           <!-- link -->
                           <div>
                              Don’t have an account?
                              <a href="register.php">Sign Up</a>
                           </div>
                        </div>
                     </form>
                  </div>
               </div>
            </div>
         </section>
      </main>

      <?php include("footer.php");?>