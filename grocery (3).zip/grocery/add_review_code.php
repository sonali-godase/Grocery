<?php

	session_start();
 	include('admin/connection.php');


	$message = $_POST['message'];
	$cust_id = $_POST['cust_id'];
	$product_id = $_POST['product_id'];



	
	$query = "INSERT INTO review(cust_id,product_id,message) VALUES('$cust_id','$product_id','$message')";


	mysqli_query($conn, $query);

	$_SESSION['success'] = "Record Added Successfully";
	header("location:product_detail.php?product_id=$product_id");

?>