<?php include("header.php");
require("admin/connection.php"); 

if(!isset($_SESSION['customer']))
{ 
  header("Locations:login.php");
}


$cust_id = $_SESSION['cust_id'];

$query = "SELECT * FROM customer WHERE cust_id = " . $cust_id;
$result = mysqli_query($conn,$query);
$row = mysqli_fetch_array($result);

$name  =  $row['name'];
$mobile=  $row['mobile'];
$email=  $row['email'];
$address =  $row['address'];

?>


<main>
   <!-- section -->
   <section>
      <div class="container">
         <!-- row -->
         <div class="row">
            <!-- col -->
            <div class="col-12">
               <div class="d-flex justify-content-between align-items-center d-md-none py-4">
                  <!-- heading -->

                  <?php

                  if (isset($_SESSION['success'])) 
                  {

                     ?>

                     <div class="alert alert-danger text-center">
                        <b>
                           <?php echo $_SESSION['success']; ?>
                        </b>
                     </div>

                     <?php 

                     unset($_SESSION['success']);
                     
                  }


                  ?>

                  <h3 class="fs-5 mb-0">Account Setting</h3>
                  <!-- button -->
                  <button class="btn btn-outline-gray-400 text-muted d-md-none btn-icon btn-sm ms-3" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasAccount" aria-controls="offcanvasAccount">
                     <i class="bi bi-text-indent-left fs-3"></i>
                  </button>
               </div>
            </div>
            <!-- col -->
            <div class="col-lg-3 col-md-4 col-12 border-end d-none d-md-block">
               <div class="pt-10 pe-lg-10">
                  <!-- nav -->
                  <ul class="nav flex-column nav-pills nav-pills-dark">
                     <!-- nav item -->
                     <li class="nav-item">
                        <a class="nav-link active" href="profile.php">
                           <i class="feather-icon icon-settings me-2"></i>
                           Profile
                        </a>
                     </li>
                     <!-- nav item -->

                     <li class="nav-item">
                        <a class="nav-link" href="orders.php">
                           <i class="feather-icon icon-shopping-bag me-2"></i>
                           Orders
                        </a>
                     </li>


                     <!-- nav item -->
                     <li class="nav-item">
                        <hr>
                     </li>
                     <!-- nav item -->
                     <li class="nav-item">
                        <a class="nav-link" href="logout.php">
                           <i class="feather-icon icon-log-out me-2"></i>
                           Log out
                        </a>
                     </li>
                  </ul>
               </div>
            </div>
            <div class="col-lg-9 col-md-8 col-12">
               <div class="py-6 p-md-6 p-lg-10">
                  <div class="mb-6">
                     <!-- heading -->
                     <h2 class="mb-0">Profile Setting</h2>
                  </div>
                  <div>
                     <!-- heading -->
                     <h5 class="mb-4">Profile details</h5>
                     <div class="row">
                        <div class="col-lg-5">
                           <!-- form -->
                           <form action="profile_code.php" method="post">
                              <!-- input -->
                              <div class="mb-3">
                                 <label class="form-label">Name</label>
                                 <input type="text" class="form-control" placeholder="jitu chauhan" name="name" value="<?= $name;?>">
                              </div>
                              <!-- input -->
                              <div class="mb-3">
                                 <label class="form-label">Email</label>
                                 <input type="email" class="form-control" placeholder="example@gmail.com" name="email" value="<?= $email;?>">
                              </div>
                              <!-- input -->
                              <div class="mb-5">
                                 <label class="form-label">Mobile</label>
                                 <input type="number" class="form-control" placeholder="Phone number" name="mobile" value="<?= $mobile;?>">
                              </div>

                              <div class="mb-5">
                                 <label class="form-label">Address</label>
                                 <input type="address" class="form-control" placeholder="Address" name="address" value="<?= $address;?>">
                              </div>

                              <!-- button -->
                              <div class="mb-3">
                                 <button class="btn btn-primary">Save Details</button>
                              </div>
                           </form>
                        </div>
                     </div>
                  </div>

               </div>
            </div>
         </div>
      </div>
   </section>
</main>





<?php include("footer.php");
?>