<?php include("header.php");
require("admin/connection.php"); 

if(!isset($_SESSION['customer']))
{ 
  header("Locations:login.php");
}


$cust_id = $_SESSION['cust_id'];

$query = "SELECT * FROM customer WHERE cust_id = " . $cust_id;
$result = mysqli_query($conn,$query);
$row = mysqli_fetch_array($result);

$name  =  $row['name'];
$mobile=  $row['mobile'];
$email=  $row['email'];
$address =  $row['address'];


$product_id = $_GET['product_id'];

$query1 = "SELECT * FROM products WHERE product_id = " . $product_id;
$result1 = mysqli_query($conn,$query1);
$row1 = mysqli_fetch_array($result1);

$title  =  $row1['title'];
$price=  $row1['price'];
$image=  $row1['image'];

?>


<main>

	<section class="mb-lg-14 mb-8 mt-8">
		<div class="container">
			<!-- row -->
			<div class="row">
				<!-- col -->
				<div class="col-12">
					<div>
						<div class="mb-8">
							<!-- text -->
							<h1 class="fw-bold mb-0">Billing</h1>

							  						</div>
					</div>
				</div>
			</div>
			<div>
				<!-- row -->
				<div class="row">
					<div class="col-lg-7 col-md-12">
						<!-- accordion -->
						<div class="mt-4 mt-lg-0">
							<div class="card shadow-sm p-4">
									<form action="profile_code.php" method="post">
                              <!-- input -->
                              <div class="mb-3">
                                 <label class="form-label">Name</label>
                                 <input type="text" class="form-control" placeholder="jitu chauhan" name="name" value="<?= $name;?>">
                              </div>
                              <!-- input -->
                              <div class="mb-3">
                                 <label class="form-label">Email</label>
                                 <input type="email" class="form-control" placeholder="example@gmail.com" name="email" value="<?= $email;?>">
                              </div>
                              <!-- input -->
                              <div class="mb-5">
                                 <label class="form-label">Mobile</label>
                                 <input type="number" class="form-control" placeholder="Phone number" name="mobile" value="<?= $mobile;?>">
                              </div>

                              <div class="mb-5">
                                 <label class="form-label">Address</label>
                                 <input type="address" class="form-control" placeholder="Address" name="address" value="<?= $address;?>">
                              </div>

                              <!-- button -->
                              <div class="mb-3">
                                 <button class="btn btn-primary">Save Details</button>
                              </div>
                           </form>

							</div>
						</div>
					</div>

					<div class="col-lg-5">
						<div class="mt-4 mt-lg-0">
							<div class="card shadow-sm">
								<h5 class="px-6 py-4 bg-transparent mb-0">Order Details</h5>
								<ul class="list-group list-group-flush">
									<!-- list group item -->
									<li class="list-group-item px-4 py-3">
										<div class="row align-items-center">
											<div class="col-2 col-md-2">
												<img src="admin/<?= $image;?>" alt="Ecommerce" class="img-fluid">
											</div>
											<div class="col-5 col-md-5">
												<h6 class="mb-0"><?= $title;?></h6>
											</div>
											<div class="col-2 col-md-2 text-center text-muted">
												<input type="number" name="qty" value="1" style="width: 30px !important">
											</div>
											<div class="col-3 text-lg-end text-start text-md-end col-md-3">
												<span class="fw-bold">$5.00</span>
											</div>
										</div>
									</li>
									<!-- list group item -->
							
									<!-- list group item -->
									<li class="list-group-item px-4 py-3">
										<div class="d-flex align-items-center justify-content-between mb-2">
											<div>Item Subtotal</div>
											<div class="fw-bold">$70.00</div>
										</div>
										<div class="d-flex align-items-center justify-content-between">
											<div>
												Service Fee
												<i class="feather-icon icon-info text-muted" data-bs-toggle="tooltip" aria-label="Default tooltip" data-bs-original-title="Default tooltip"></i>
											</div>
											<div class="fw-bold">$3.00</div>
										</div>
									</li>
									<!-- list group item -->
									<li class="list-group-item px-4 py-3">
										<div class="d-flex align-items-center justify-content-between fw-bold">
											<div>Subtotal</div>
											<div>$73.00</div>
										</div>
									</li>
								</ul>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
</main>

<?php include("footer.php");?>