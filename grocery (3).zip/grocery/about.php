<?php include("header.php");?>

<main>
			<!-- section -->
			<section class="mt-lg-14 mt-8">
				<!-- container -->
				<div class="container">
					<!-- row -->
					<div class="row">
						<!-- col -->
						<div class="offset-lg-1 col-lg-10 col-12">
							<div class="row align-items-center mb-14">
								<div class="col-md-6">
									<!-- text -->
									<div class="ms-xxl-14 me-xxl-15 mb-8 mb-md-0 text-center text-md-start">
										<h1 class="mb-6">The Future of Grocery Delivery:</h1>
										<p class="mb-0 lead">By powering the future of grocery with our retail partners, we give everyone access to the food they love and more time to enjoy it together.</p>
									</div>
								</div>
								<!-- col -->
								<div class="col-md-6">
									<div >
										<!-- img -->
										<img src="assets/images/about/about-img.jpg" alt="" class="img-fluid rounded" shadow bg-warning bg-gradient >
									</div>
								</div>
							</div>
							<!-- row -->
							<div class="row mb-12">
								<div class="col-12">
									<div class="mb-8">
										<!-- heading -->
										<h2> Team Members </h2>
									</div>
								</div>
								<div class="col-md-3">
									<!-- card -->
									<div class="card bg-light mb-6 border-0">
										<!-- card body -->
										<div class="card-body p-8">
											<div class="mb-4">
												<!-- img -->
												<!--<img src="assets/images/about/about-icons-1.svg" alt="">-->
											</div>
											<h4> E-Grocery shop <br>Developed  and planning By <br>Rutuja Ingawale</h4>
											<p> </p>
											<!-- btn -->
											
										</div>
									</div>
								</div>
								<div class="col-md-3">
									<!-- card -->
									<div class="card bg-light mb-6 border-0">
										<!-- card body -->
										<div class="card-body p-8">
											<div class="mb-4">
												<!-- img -->
												<!--<img src="assets/images/about/about-icons-2.svg" alt="">-->
											</div>
											<h4> E-Grocery shop <br>Developed  and planning By <br>Sonali Godase</h4>
											<p></p>
											<!-- btn -->
											
										</div>
									</div>
								</div>
								<div class="col-md-3">
									<!-- card -->
									<div class="card bg-light mb-6 border-0">
										<!-- card body -->
										<div class="card-body p-8">
											<div class="mb-4">
												<!-- img -->
												<!--<img src="assets/images/about/about-icons-3.svg" alt="">-->
											</div>
											<h4> E-Grocery shop <br>Developed  and planning By <br>Akanksha Mali</h4>
											<p></p>
											<!-- btn -->
											
										</div>
									</div>
								</div>
								<div class="col-md-3">
									<!-- card -->
									<div class="card bg-light mb-6 border-0">
										<!-- card body -->
										<div class="card-body p-8">
											<div class="mb-4">
												<!-- img -->
												<!--<img src="assets/images/about/about-icons-3.svg" alt="">-->
											</div>
											<h4> E-Grocery shop <br>Project Documentation <br> Sayali Mane </h4>
											<p></p>
											<!-- btn -->
											
										</div>
									</div>
								</div>
								<div class="col-md-3">
									<!-- card -->
									<div class="card bg-light mb-6 border-0">
										<!-- card body -->
										<div class="card-body p-8">
											<div class="mb-4">
												<!-- img -->
												<!--<img src="assets/images/about/about-icons-3.svg" alt="">-->
											</div>
											<h4> E-Grocery shop <br>Testing work  <br>Disha kalal </h4>
											<p></p>
											<!-- btn -->
											
										</div>
									</div>
								</div>

								<div class="col">
									<!-- text -->
									
								</div>
							</div>
						</div>
					</div>
				</div>
			</section>
			<!-- section -->
	
		</main>


		<?php include("footer.php");?>