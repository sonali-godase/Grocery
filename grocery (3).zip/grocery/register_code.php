<?php
	    require("admin/connection.php");

		$name = $_POST['name'];
        $mobile = $_POST['mobile'];
        $email = $_POST['email'];
        $address = $_POST['address'];
        $password = $_POST['password'];

        
	 	$query = "SELECT * FROM customer where email='$email'";
         $result =  mysqli_query($conn, $query);
        $rows = mysqli_num_rows($result);
        if($rows>0)
		{
            
                session_start();
              $_SESSION['success'] = "Email Already Exists..!!";                      
			  header("Location:register.php");
		}
		else
		{
		 		

		           
                    $query = "INSERT INTO customer(name,mobile, email, address, password) ";	
                    $query .= "VALUES('$name','$mobile', '$email', '$address', '$password')";
                    mysqli_query($conn, $query);

                    session_start();
                    $_SESSION['success'] = "Registration Successfull...!!";     
                     header("Location: login.php");
            
        }

?>