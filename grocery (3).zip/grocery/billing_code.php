<?php
require("admin/connection.php");

$cust_id = $_POST['cust_id'];
$product_id = $_POST['product_id'];
$quantity = $_POST['quantity'];
$final_total = $_POST['final_total'];


$query = "INSERT INTO orders(cust_id,product_id, qty, total) ";	
$query .= "VALUES('$cust_id','$product_id', '$quantity', '$final_total')";


mysqli_query($conn, $query);
 
header("Location: order_success.php");

?>