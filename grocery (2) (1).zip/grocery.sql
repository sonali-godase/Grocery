-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 31, 2024 at 08:53 AM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `grocery`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `admin_id` int(100) NOT NULL,
  `name` varchar(200) NOT NULL,
  `email` varchar(200) NOT NULL,
  `mobile` varchar(15) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`admin_id`, `name`, `email`, `mobile`, `password`) VALUES
(1, 'admin', 'admin', '789', '123');

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `cat_id` int(100) NOT NULL,
  `cat_name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`cat_id`, `cat_name`) VALUES
(1, 'Sugar'),
(2, 'Salt'),
(3, 'Bath Soap'),
(4, 'Cloth Soap'),
(5, 'Washing Powder'),
(6, 'Tea'),
(8, 'Butter'),
(9, 'Biscuit');

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `cust_id` int(100) NOT NULL,
  `name` varchar(200) NOT NULL,
  `email` varchar(200) NOT NULL,
  `mobile` varchar(15) NOT NULL,
  `password` varchar(100) NOT NULL,
  `address` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`cust_id`, `name`, `email`, `mobile`, `password`, `address`) VALUES
(1, 'Akanksha Mali', 'akankshamali@gmail.com', '9322154515', '123', 'Gaudwadi'),
(2, 'Rutuja Ingawale', 'rutuja@gmail.com', '9325747279', '123', 'Medeshigi'),
(3, 'Ganesh Uttam Sutar', 'admin@gmail.com', '07387140146', '123', 'Dighanchi Road'),
(4, 'Ganesh Sutar', 'admin@chandellebooks.com', '07387140146', 'admin', 'Near 100 ft Road'),
(5, 'Sonali Godase', 'sonu@gmail.com', '2266655010', '2266', 'Kola');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `order_id` int(100) NOT NULL,
  `cust_id` varchar(100) NOT NULL,
  `product_id` varchar(100) NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp(),
  `total` varchar(200) NOT NULL,
  `qty` varchar(100) NOT NULL,
  `status` varchar(100) NOT NULL DEFAULT 'In process'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`order_id`, `cust_id`, `product_id`, `date`, `total`, `qty`, `status`) VALUES
(1, '2', '4', '2024-03-20 15:05:42', '132', '1', 'Completed'),
(2, '1', '5', '2024-03-21 14:57:59', '5', '1', 'In process'),
(3, '1', '6', '2024-03-21 15:10:58', 'NaN', '2', 'In process'),
(4, '5', '7', '2024-03-22 16:04:20', '10', '1', 'In process'),
(5, '2', '12', '2024-03-23 06:56:48', '300', '1', 'In process'),
(6, '5', '7', '2024-03-31 05:10:58', '10', '1', 'In process'),
(7, '5', '11', '2024-03-31 05:11:16', '50', '1', 'In process'),
(8, '5', '10', '2024-03-31 05:11:31', '51', '1', 'In process'),
(9, '5', '2', '2024-03-31 05:13:40', '98', '2', 'In process'),
(10, '5', '1', '2024-03-31 05:16:43', '455', '1', 'In process'),
(11, '4', '6', '2024-03-31 06:03:14', '10', '1', 'In process');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `product_id` int(11) NOT NULL,
  `title` varchar(2000) NOT NULL,
  `price` varchar(200) NOT NULL,
  `cat_id` varchar(100) NOT NULL,
  `description` varchar(5000) NOT NULL,
  `image` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`product_id`, `title`, `price`, `cat_id`, `description`, `image`) VALUES
(1, 'Tide Double Power Jasmine & Rose Detergent Powder 6 Kg', '455', '5', ' Tide Plus Double power Jasmine and Rose detergent washing powder 6Kg + 2KG free New Tide Plus with extra power detergent, now with the added ', 'upload/washing.jpg'),
(2, 'Aashirvaad iodized salt 1 kg', '49', '2', 'Aashirvaad ensures that only good quality ingredients reach your kitchen and Aashirvaad Iodised Salt stays true to that promise. ', 'upload/salt.jpg'),
(3, 'WOW Skin Science Aloe Vera Hydrating Bar', '375', '3', 'Key Ingredients: Aloe Vera How to use: Apply on wet skin all over the body. Use a loofah or your hands to gently work up a lather. ', 'upload/soap2.jpg'),
(4, 'Jo Lime Sparkling Fresh Soap with Glycerine 150 g (Pack of 4)', '132', '3', 'Order Jo Lime Sparkling Fresh Soap with Glycerine 150 g (Pack of 4) online at Jiomart and save.', 'upload/shopping.jpg'),
(5, 'Parle-G', '10', '9', '    Parleg-G   ', 'upload/buscuit.jpg'),
(6, 'Parle-G gold', '10 ', '9', '     Parle-G gold   ', 'upload/Parle-G gold.jpg'),
(7, 'Good Day', '10', '9', '    Good Day  ', 'upload/gooday.jpg'),
(8, 'Mari gold', '10', '9', '    Mari gold  ', 'upload/marie.jpg'),
(9, 'Borbon', '10', '9', '    Borbon  ', 'upload/bourbon.jpg'),
(10, 'Red Label', '51', '6', '   Brooke Bond , Red Label,Basil, Cardamom, Ginger 100 Grams ', 'upload/red_label.jpg'),
(11, 'TATA TEA', '50', '6', '     Rich Tast Irresistible Aroma    ', 'upload/tata_gold.jpg'),
(12, 'GS TEA', '300', '6', '    GS Tea LEAF 1 KG Tea Box  (1 kg)  ', 'upload/GS_Tea.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `review`
--

CREATE TABLE `review` (
  `review_id` int(11) NOT NULL,
  `cust_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `message` varchar(2000) NOT NULL,
  `image` varchar(1000) NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `review`
--

INSERT INTO `review` (`review_id`, `cust_id`, `product_id`, `message`, `image`, `date`) VALUES
(1, 4, 5, 'good Product', 'reviews/holi 1.png', '2024-03-31 06:47:36'),
(2, 4, 5, '  Received Quality product', 'reviews/house.jpg', '2024-03-31 06:48:24'),
(3, 4, 3, '  Nice produtc', 'reviews/logistic1.png', '2024-03-31 06:50:42'),
(4, 4, 3, ' Quality product', '', '2024-03-31 06:52:37');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`cat_id`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`cust_id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`order_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`product_id`);

--
-- Indexes for table `review`
--
ALTER TABLE `review`
  ADD PRIMARY KEY (`review_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `admin_id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `cat_id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `customer`
--
ALTER TABLE `customer`
  MODIFY `cust_id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `order_id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `product_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `review`
--
ALTER TABLE `review`
  MODIFY `review_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
